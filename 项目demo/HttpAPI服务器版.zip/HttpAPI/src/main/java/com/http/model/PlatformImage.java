package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("platform_image")
public class PlatformImage extends Model<PlatformImage> {

    private static final long serialVersionUID = 1L;

	@TableId(value="platform_image_id", type= IdType.AUTO)
	private Integer platformImageId;
	@TableField("platform_information_id")
	private Integer platformInformationId;
	@TableField("platform_image_url")
	private String platformImageUrl;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getPlatformImageId() {
		return platformImageId;
	}

	public void setPlatformImageId(Integer platformImageId) {
		this.platformImageId = platformImageId;
	}

	public Integer getPlatformInformationId() {
		return platformInformationId;
	}

	public void setPlatformInformationId(Integer platformInformationId) {
		this.platformInformationId = platformInformationId;
	}

	public String getPlatformImageUrl() {
		return platformImageUrl;
	}

	public void setPlatformImageUrl(String platformImageUrl) {
		this.platformImageUrl = platformImageUrl;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.platformImageId;
	}

	@Override
	public String toString() {
		return "PlatformImage{" +
			"platformImageId=" + platformImageId +
			", platformInformationId=" + platformInformationId +
			", platformImageUrl=" + platformImageUrl +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
