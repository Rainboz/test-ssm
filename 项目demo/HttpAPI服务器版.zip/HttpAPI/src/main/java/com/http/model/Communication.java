package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Communication extends Model<Communication> {

    private static final long serialVersionUID = 1L;

	@TableId(value="communication_id", type= IdType.AUTO)
	private Integer communicationId;
	@TableField("lesson_id")
	private Integer lessonId;
	@TableField("communication_author")
	private Integer communicationAuthor;
	@TableField("communication_content")
	private String communicationContent;
	@TableField("communication_image_count")
	private Integer communicationImageCount;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCommunicationId() {
		return communicationId;
	}

	public void setCommunicationId(Integer communicationId) {
		this.communicationId = communicationId;
	}

	public Integer getLessonId() {
		return lessonId;
	}

	public void setLessonId(Integer lessonId) {
		this.lessonId = lessonId;
	}

	public Integer getCommunicationAuthor() {
		return communicationAuthor;
	}

	public void setCommunicationAuthor(Integer communicationAuthor) {
		this.communicationAuthor = communicationAuthor;
	}

	public String getCommunicationContent() {
		return communicationContent;
	}

	public void setCommunicationContent(String communicationContent) {
		this.communicationContent = communicationContent;
	}

	public Integer getCommunicationImageCount() {
		return communicationImageCount;
	}

	public void setCommunicationImageCount(Integer communicationImageCount) {
		this.communicationImageCount = communicationImageCount;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.communicationId;
	}

	@Override
	public String toString() {
		return "Communication{" +
			"communicationId=" + communicationId +
			", lessonId=" + lessonId +
			", communicationAuthor=" + communicationAuthor +
			", communicationContent=" + communicationContent +
			", communicationImageCount=" + communicationImageCount +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
