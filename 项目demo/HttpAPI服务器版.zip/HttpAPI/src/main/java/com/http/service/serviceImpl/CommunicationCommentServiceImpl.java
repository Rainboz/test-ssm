package com.http.service.serviceImpl;

import com.http.model.CommunicationComment;
import com.http.dao.CommunicationCommentDao;
import com.http.service.CommunicationCommentService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class CommunicationCommentServiceImpl extends ServiceImpl<CommunicationCommentDao, CommunicationComment> implements CommunicationCommentService {
	
}
