package com.http.service.serviceImpl;

import com.http.model.CommunicationPraise;
import com.http.dao.CommunicationPraiseDao;
import com.http.service.CommunicationPraiseService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class CommunicationPraiseServiceImpl extends ServiceImpl<CommunicationPraiseDao, CommunicationPraise> implements CommunicationPraiseService {
	
}
