package com.http.service.serviceImpl;

import com.http.model.DynamicImage;
import com.http.dao.DynamicImageDao;
import com.http.service.DynamicImageService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class DynamicImageServiceImpl extends ServiceImpl<DynamicImageDao, DynamicImage> implements DynamicImageService {
	
}
