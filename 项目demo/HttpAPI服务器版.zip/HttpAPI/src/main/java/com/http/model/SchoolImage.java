package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("school_image")
public class SchoolImage extends Model<SchoolImage> {

    private static final long serialVersionUID = 1L;

	@TableId(value="school_image_id", type= IdType.AUTO)
	private Integer schoolImageId;
	@TableField("school_information_id")
	private Integer schoolInformationId;
	@TableField("school_image_url")
	private String schoolImageUrl;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getSchoolImageId() {
		return schoolImageId;
	}

	public void setSchoolImageId(Integer schoolImageId) {
		this.schoolImageId = schoolImageId;
	}

	public Integer getSchoolInformationId() {
		return schoolInformationId;
	}

	public void setSchoolInformationId(Integer schoolInformationId) {
		this.schoolInformationId = schoolInformationId;
	}

	public String getSchoolImageUrl() {
		return schoolImageUrl;
	}

	public void setSchoolImageUrl(String schoolImageUrl) {
		this.schoolImageUrl = schoolImageUrl;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.schoolImageId;
	}

	@Override
	public String toString() {
		return "SchoolImage{" +
			"schoolImageId=" + schoolImageId +
			", schoolInformationId=" + schoolInformationId +
			", schoolImageUrl=" + schoolImageUrl +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
