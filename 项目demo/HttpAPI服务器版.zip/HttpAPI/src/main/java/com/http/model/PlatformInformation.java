package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("platform_information")
public class PlatformInformation extends Model<PlatformInformation> {

    private static final long serialVersionUID = 1L;

	@TableId(value="platform_information_id", type= IdType.AUTO)
	private Integer platformInformationId;
	@TableField("platform_information_title")
	private String platformInformationTitle;
	@TableField("platform_information_content")
	private String platformInformationContent;
	@TableField("platform_information_author")
	private String platformInformationAuthor;
	@TableField("information_image_count")
	private Integer informationImageCount;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getPlatformInformationId() {
		return platformInformationId;
	}

	public void setPlatformInformationId(Integer platformInformationId) {
		this.platformInformationId = platformInformationId;
	}

	public String getPlatformInformationTitle() {
		return platformInformationTitle;
	}

	public void setPlatformInformationTitle(String platformInformationTitle) {
		this.platformInformationTitle = platformInformationTitle;
	}

	public String getPlatformInformationContent() {
		return platformInformationContent;
	}

	public void setPlatformInformationContent(String platformInformationContent) {
		this.platformInformationContent = platformInformationContent;
	}

	public String getPlatformInformationAuthor() {
		return platformInformationAuthor;
	}

	public void setPlatformInformationAuthor(String platformInformationAuthor) {
		this.platformInformationAuthor = platformInformationAuthor;
	}

	public Integer getInformationImageCount() {
		return informationImageCount;
	}

	public void setInformationImageCount(Integer informationImageCount) {
		this.informationImageCount = informationImageCount;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.platformInformationId;
	}

	@Override
	public String toString() {
		return "PlatformInformation{" +
			"platformInformationId=" + platformInformationId +
			", platformInformationTitle=" + platformInformationTitle +
			", platformInformationContent=" + platformInformationContent +
			", platformInformationAuthor=" + platformInformationAuthor +
			", informationImageCount=" + informationImageCount +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
