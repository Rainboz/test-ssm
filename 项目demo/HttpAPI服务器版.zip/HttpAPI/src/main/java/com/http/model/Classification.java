package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Classification extends Model<Classification> {

    private static final long serialVersionUID = 1L;

	@TableId(value="classification_id", type= IdType.AUTO)
	private Integer classificationId;
	@TableField("classification_name")
	private String classificationName;
	@TableField("classification_own")
	private Integer classificationOwn;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getClassificationId() {
		return classificationId;
	}

	public void setClassificationId(Integer classificationId) {
		this.classificationId = classificationId;
	}

	public String getClassificationName() {
		return classificationName;
	}

	public void setClassificationName(String classificationName) {
		this.classificationName = classificationName;
	}

	public Integer getClassificationOwn() {
		return classificationOwn;
	}

	public void setClassificationOwn(Integer classificationOwn) {
		this.classificationOwn = classificationOwn;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.classificationId;
	}

	@Override
	public String toString() {
		return "Classification{" +
			"classificationId=" + classificationId +
			", classificationName=" + classificationName +
			", classificationOwn=" + classificationOwn +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
