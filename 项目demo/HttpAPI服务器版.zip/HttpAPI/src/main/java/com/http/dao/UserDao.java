package com.http.dao;

import java.util.List;

import com.http.model.User;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public interface UserDao extends BaseMapper<User> {
	List<User> findAll();
	User selectByPrimaryKey(Integer id);
}