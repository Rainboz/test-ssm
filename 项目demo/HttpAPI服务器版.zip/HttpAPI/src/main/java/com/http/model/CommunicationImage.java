package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("communication_image")
public class CommunicationImage extends Model<CommunicationImage> {

    private static final long serialVersionUID = 1L;

	@TableId(value="communication_image_id", type= IdType.AUTO)
	private Integer communicationImageId;
	@TableField("communication_id")
	private Integer communicationId;
	@TableField("communication_image_url")
	private String communicationImageUrl;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCommunicationImageId() {
		return communicationImageId;
	}

	public void setCommunicationImageId(Integer communicationImageId) {
		this.communicationImageId = communicationImageId;
	}

	public Integer getCommunicationId() {
		return communicationId;
	}

	public void setCommunicationId(Integer communicationId) {
		this.communicationId = communicationId;
	}

	public String getCommunicationImageUrl() {
		return communicationImageUrl;
	}

	public void setCommunicationImageUrl(String communicationImageUrl) {
		this.communicationImageUrl = communicationImageUrl;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.communicationImageId;
	}

	@Override
	public String toString() {
		return "CommunicationImage{" +
			"communicationImageId=" + communicationImageId +
			", communicationId=" + communicationId +
			", communicationImageUrl=" + communicationImageUrl +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
