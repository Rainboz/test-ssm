package com.http.service.serviceImpl;

import com.http.model.MyPracticalTraining;
import com.http.dao.MyPracticalTrainingDao;
import com.http.service.MyPracticalTrainingService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class MyPracticalTrainingServiceImpl extends ServiceImpl<MyPracticalTrainingDao, MyPracticalTraining> implements MyPracticalTrainingService {
	
}
