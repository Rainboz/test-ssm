package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("communication_praise")
public class CommunicationPraise extends Model<CommunicationPraise> {

    private static final long serialVersionUID = 1L;

	@TableId(value="communication_praise_id", type= IdType.AUTO)
	private Integer communicationPraiseId;
	@TableField("communication_id")
	private Integer communicationId;
	@TableField("communication_praise_user")
	private Integer communicationPraiseUser;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCommunicationPraiseId() {
		return communicationPraiseId;
	}

	public void setCommunicationPraiseId(Integer communicationPraiseId) {
		this.communicationPraiseId = communicationPraiseId;
	}

	public Integer getCommunicationId() {
		return communicationId;
	}

	public void setCommunicationId(Integer communicationId) {
		this.communicationId = communicationId;
	}

	public Integer getCommunicationPraiseUser() {
		return communicationPraiseUser;
	}

	public void setCommunicationPraiseUser(Integer communicationPraiseUser) {
		this.communicationPraiseUser = communicationPraiseUser;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.communicationPraiseId;
	}

	@Override
	public String toString() {
		return "CommunicationPraise{" +
			"communicationPraiseId=" + communicationPraiseId +
			", communicationId=" + communicationId +
			", communicationPraiseUser=" + communicationPraiseUser +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
