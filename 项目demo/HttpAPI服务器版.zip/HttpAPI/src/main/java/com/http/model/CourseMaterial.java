package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("course_material")
public class CourseMaterial extends Model<CourseMaterial> {

    private static final long serialVersionUID = 1L;

	@TableId(value="course_material_id", type= IdType.AUTO)
	private Integer courseMaterialId;
	@TableField("course_id")
	private Integer courseId;
	@TableField("course_material_name")
	private String courseMaterialName;
	@TableField("course_material_url")
	private String courseMaterialUrl;
	@TableField("course_material_size")
	private String courseMaterialSize;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCourseMaterialId() {
		return courseMaterialId;
	}

	public void setCourseMaterialId(Integer courseMaterialId) {
		this.courseMaterialId = courseMaterialId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseMaterialName() {
		return courseMaterialName;
	}

	public void setCourseMaterialName(String courseMaterialName) {
		this.courseMaterialName = courseMaterialName;
	}

	public String getCourseMaterialUrl() {
		return courseMaterialUrl;
	}

	public void setCourseMaterialUrl(String courseMaterialUrl) {
		this.courseMaterialUrl = courseMaterialUrl;
	}

	public String getCourseMaterialSize() {
		return courseMaterialSize;
	}

	public void setCourseMaterialSize(String courseMaterialSize) {
		this.courseMaterialSize = courseMaterialSize;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.courseMaterialId;
	}

	@Override
	public String toString() {
		return "CourseMaterial{" +
			"courseMaterialId=" + courseMaterialId +
			", courseId=" + courseId +
			", courseMaterialName=" + courseMaterialName +
			", courseMaterialUrl=" + courseMaterialUrl +
			", courseMaterialSize=" + courseMaterialSize +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
