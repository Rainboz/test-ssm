package com.http.dao;

import com.http.model.Subscribe;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public interface SubscribeDao extends BaseMapper<Subscribe> {

}