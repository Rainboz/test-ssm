package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("sensitive_word")
public class SensitiveWord extends Model<SensitiveWord> {

    private static final long serialVersionUID = 1L;

	@TableId(value="sensitive_word_id", type= IdType.AUTO)
	private Integer sensitiveWordId;
	@TableField("school_id")
	private Integer schoolId;
	@TableField("sensitive_word")
	private String sensitiveWord;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getSensitiveWordId() {
		return sensitiveWordId;
	}

	public void setSensitiveWordId(Integer sensitiveWordId) {
		this.sensitiveWordId = sensitiveWordId;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public String getSensitiveWord() {
		return sensitiveWord;
	}

	public void setSensitiveWord(String sensitiveWord) {
		this.sensitiveWord = sensitiveWord;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.sensitiveWordId;
	}

	@Override
	public String toString() {
		return "SensitiveWord{" +
			"sensitiveWordId=" + sensitiveWordId +
			", schoolId=" + schoolId +
			", sensitiveWord=" + sensitiveWord +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
