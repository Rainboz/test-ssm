package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("practical_training")
public class PracticalTraining extends Model<PracticalTraining> {

    private static final long serialVersionUID = 1L;

	@TableId(value="practical_training_id", type= IdType.AUTO)
	private Integer practicalTrainingId;
	@TableField("course_id")
	private Integer courseId;
	@TableField("practical_training_describe")
	private String practicalTrainingDescribe;
	@TableField("practical_training_plan")
	private String practicalTrainingPlan;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getPracticalTrainingId() {
		return practicalTrainingId;
	}

	public void setPracticalTrainingId(Integer practicalTrainingId) {
		this.practicalTrainingId = practicalTrainingId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getPracticalTrainingDescribe() {
		return practicalTrainingDescribe;
	}

	public void setPracticalTrainingDescribe(String practicalTrainingDescribe) {
		this.practicalTrainingDescribe = practicalTrainingDescribe;
	}

	public String getPracticalTrainingPlan() {
		return practicalTrainingPlan;
	}

	public void setPracticalTrainingPlan(String practicalTrainingPlan) {
		this.practicalTrainingPlan = practicalTrainingPlan;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.practicalTrainingId;
	}

	@Override
	public String toString() {
		return "PracticalTraining{" +
			"practicalTrainingId=" + practicalTrainingId +
			", courseId=" + courseId +
			", practicalTrainingDescribe=" + practicalTrainingDescribe +
			", practicalTrainingPlan=" + practicalTrainingPlan +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
