package com.http.service;

import java.util.List;

import com.http.model.User;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public interface UserService extends IService<User> {
	List<User> findAll();
	User selectByPrimaryKey(Integer id);
}
