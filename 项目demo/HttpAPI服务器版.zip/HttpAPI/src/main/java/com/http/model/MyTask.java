package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("my_task")
public class MyTask extends Model<MyTask> {

    private static final long serialVersionUID = 1L;

	@TableId(value="my_task_id", type= IdType.AUTO)
	private Integer myTaskId;
	@TableField("task_id")
	private Integer taskId;
	@TableField("student_id")
	private Integer studentId;
	@TableField("my_task_state")
	private Integer myTaskState;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getMyTaskId() {
		return myTaskId;
	}

	public void setMyTaskId(Integer myTaskId) {
		this.myTaskId = myTaskId;
	}

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getMyTaskState() {
		return myTaskState;
	}

	public void setMyTaskState(Integer myTaskState) {
		this.myTaskState = myTaskState;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.myTaskId;
	}

	@Override
	public String toString() {
		return "MyTask{" +
			"myTaskId=" + myTaskId +
			", taskId=" + taskId +
			", studentId=" + studentId +
			", myTaskState=" + myTaskState +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
