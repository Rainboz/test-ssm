package com.http.service;

import com.http.model.PlatformImage;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public interface PlatformImageService extends IService<PlatformImage> {
	
}
