package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Banner extends Model<Banner> {

    private static final long serialVersionUID = 1L;

	@TableId(value="banner_id", type= IdType.AUTO)
	private Integer bannerId;
	@TableField("school_id")
	private Integer schoolId;
	@TableField("banner_image")
	private String bannerImage;
	@TableField("banner_type")
	private Integer bannerType;
	@TableField("banner_link")
	private String bannerLink;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getBannerId() {
		return bannerId;
	}

	public void setBannerId(Integer bannerId) {
		this.bannerId = bannerId;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public String getBannerImage() {
		return bannerImage;
	}

	public void setBannerImage(String bannerImage) {
		this.bannerImage = bannerImage;
	}

	public Integer getBannerType() {
		return bannerType;
	}

	public void setBannerType(Integer bannerType) {
		this.bannerType = bannerType;
	}

	public String getBannerLink() {
		return bannerLink;
	}

	public void setBannerLink(String bannerLink) {
		this.bannerLink = bannerLink;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.bannerId;
	}

	@Override
	public String toString() {
		return "Banner{" +
			"bannerId=" + bannerId +
			", schoolId=" + schoolId +
			", bannerImage=" + bannerImage +
			", bannerType=" + bannerType +
			", bannerLink=" + bannerLink +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
