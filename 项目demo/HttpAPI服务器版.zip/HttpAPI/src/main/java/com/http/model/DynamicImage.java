package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("dynamic_image")
public class DynamicImage extends Model<DynamicImage> {

    private static final long serialVersionUID = 1L;

	@TableId(value="dynamic_image_id", type= IdType.AUTO)
	private Integer dynamicImageId;
	@TableField("circle_dynamic_id")
	private Integer circleDynamicId;
	@TableField("dynamic_image_url")
	private String dynamicImageUrl;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getDynamicImageId() {
		return dynamicImageId;
	}

	public void setDynamicImageId(Integer dynamicImageId) {
		this.dynamicImageId = dynamicImageId;
	}

	public Integer getCircleDynamicId() {
		return circleDynamicId;
	}

	public void setCircleDynamicId(Integer circleDynamicId) {
		this.circleDynamicId = circleDynamicId;
	}

	public String getDynamicImageUrl() {
		return dynamicImageUrl;
	}

	public void setDynamicImageUrl(String dynamicImageUrl) {
		this.dynamicImageUrl = dynamicImageUrl;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.dynamicImageId;
	}

	@Override
	public String toString() {
		return "DynamicImage{" +
			"dynamicImageId=" + dynamicImageId +
			", circleDynamicId=" + circleDynamicId +
			", dynamicImageUrl=" + dynamicImageUrl +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
