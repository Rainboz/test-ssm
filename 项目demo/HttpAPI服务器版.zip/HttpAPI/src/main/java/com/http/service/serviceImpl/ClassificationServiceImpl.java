package com.http.service.serviceImpl;

import com.http.model.Classification;
import com.http.dao.ClassificationDao;
import com.http.service.ClassificationService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class ClassificationServiceImpl extends ServiceImpl<ClassificationDao, Classification> implements ClassificationService {
	
}
