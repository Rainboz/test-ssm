package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class School extends Model<School> {

    private static final long serialVersionUID = 1L;

	@TableId(value="school_id", type= IdType.AUTO)
	private Integer schoolId;
	@TableField("school_code")
	private String schoolCode;
	@TableField("school_name")
	private String schoolName;
	@TableField("school_badge")
	private String schoolBadge;
	@TableField("school_introduce")
	private String schoolIntroduce;
	@TableField("school_background")
	private String schoolBackground;
	@TableField("school_city")
	private String schoolCity;
	@TableField("school_province")
	private String schoolProvince;
	@TableField("school_type")
	private Integer schoolType;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolCode() {
		return schoolCode;
	}

	public void setSchoolCode(String schoolCode) {
		this.schoolCode = schoolCode;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolBadge() {
		return schoolBadge;
	}

	public void setSchoolBadge(String schoolBadge) {
		this.schoolBadge = schoolBadge;
	}

	public String getSchoolIntroduce() {
		return schoolIntroduce;
	}

	public void setSchoolIntroduce(String schoolIntroduce) {
		this.schoolIntroduce = schoolIntroduce;
	}

	public String getSchoolBackground() {
		return schoolBackground;
	}

	public void setSchoolBackground(String schoolBackground) {
		this.schoolBackground = schoolBackground;
	}

	public String getSchoolCity() {
		return schoolCity;
	}

	public void setSchoolCity(String schoolCity) {
		this.schoolCity = schoolCity;
	}

	public String getSchoolProvince() {
		return schoolProvince;
	}

	public void setSchoolProvince(String schoolProvince) {
		this.schoolProvince = schoolProvince;
	}

	public Integer getSchoolType() {
		return schoolType;
	}

	public void setSchoolType(Integer schoolType) {
		this.schoolType = schoolType;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.schoolId;
	}

	@Override
	public String toString() {
		return "School{" +
			"schoolId=" + schoolId +
			", schoolCode=" + schoolCode +
			", schoolName=" + schoolName +
			", schoolBadge=" + schoolBadge +
			", schoolIntroduce=" + schoolIntroduce +
			", schoolBackground=" + schoolBackground +
			", schoolCity=" + schoolCity +
			", schoolProvince=" + schoolProvince +
			", schoolType=" + schoolType +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
