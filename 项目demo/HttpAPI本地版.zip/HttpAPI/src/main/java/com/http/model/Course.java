package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.math.BigDecimal;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Course extends Model<Course> {

    private static final long serialVersionUID = 1L;

	@TableId(value="course_id", type= IdType.AUTO)
	private Integer courseId;
	@TableField("course_code")
	private String courseCode;
	@TableField("course_name")
	private String courseName;
	@TableField("course_introduce")
	private String courseIntroduce;
	@TableField("course_teacher")
	private Integer courseTeacher;
	@TableField("school_id")
	private Integer schoolId;
	@TableField("faculty_id")
	private Integer facultyId;
	@TableField("class_id")
	private Integer classId;
	@TableField("course_classification")
	private Integer courseClassification;
	@TableField("course_sum_student")
	private Integer courseSumStudent;
	@TableField("course_learn_student")
	private Integer courseLearnStudent;
	@TableField("course_cover")
	private String courseCover;
	@TableField("course_type")
	private Integer courseType;
	@TableField("course_finish")
	private Integer courseFinish;
	@TableField("course_sum")
	private Integer courseSum;
	@TableField("course_price")
	private BigDecimal coursePrice;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseIntroduce() {
		return courseIntroduce;
	}

	public void setCourseIntroduce(String courseIntroduce) {
		this.courseIntroduce = courseIntroduce;
	}

	public Integer getCourseTeacher() {
		return courseTeacher;
	}

	public void setCourseTeacher(Integer courseTeacher) {
		this.courseTeacher = courseTeacher;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public Integer getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}

	public Integer getClassId() {
		return classId;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	public Integer getCourseClassification() {
		return courseClassification;
	}

	public void setCourseClassification(Integer courseClassification) {
		this.courseClassification = courseClassification;
	}

	public Integer getCourseSumStudent() {
		return courseSumStudent;
	}

	public void setCourseSumStudent(Integer courseSumStudent) {
		this.courseSumStudent = courseSumStudent;
	}

	public Integer getCourseLearnStudent() {
		return courseLearnStudent;
	}

	public void setCourseLearnStudent(Integer courseLearnStudent) {
		this.courseLearnStudent = courseLearnStudent;
	}

	public String getCourseCover() {
		return courseCover;
	}

	public void setCourseCover(String courseCover) {
		this.courseCover = courseCover;
	}

	public Integer getCourseType() {
		return courseType;
	}

	public void setCourseType(Integer courseType) {
		this.courseType = courseType;
	}

	public Integer getCourseFinish() {
		return courseFinish;
	}

	public void setCourseFinish(Integer courseFinish) {
		this.courseFinish = courseFinish;
	}

	public Integer getCourseSum() {
		return courseSum;
	}

	public void setCourseSum(Integer courseSum) {
		this.courseSum = courseSum;
	}

	public BigDecimal getCoursePrice() {
		return coursePrice;
	}

	public void setCoursePrice(BigDecimal coursePrice) {
		this.coursePrice = coursePrice;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.courseId;
	}

	@Override
	public String toString() {
		return "Course{" +
			"courseId=" + courseId +
			", courseCode=" + courseCode +
			", courseName=" + courseName +
			", courseIntroduce=" + courseIntroduce +
			", courseTeacher=" + courseTeacher +
			", schoolId=" + schoolId +
			", facultyId=" + facultyId +
			", classId=" + classId +
			", courseClassification=" + courseClassification +
			", courseSumStudent=" + courseSumStudent +
			", courseLearnStudent=" + courseLearnStudent +
			", courseCover=" + courseCover +
			", courseType=" + courseType +
			", courseFinish=" + courseFinish +
			", courseSum=" + courseSum +
			", coursePrice=" + coursePrice +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
