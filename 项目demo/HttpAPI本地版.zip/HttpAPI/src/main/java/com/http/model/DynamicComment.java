package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("dynamic_comment")
public class DynamicComment extends Model<DynamicComment> {

    private static final long serialVersionUID = 1L;

	@TableId(value="dynamic_comment_id", type= IdType.AUTO)
	private Integer dynamicCommentId;
	@TableField("dynamic_comment_author")
	private Integer dynamicCommentAuthor;
	@TableField("circle_dynamic_id")
	private Integer circleDynamicId;
	@TableField("dynamic_reply_user")
	private Integer dynamicReplyUser;
	@TableField("dynamic_comment_content")
	private String dynamicCommentContent;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getDynamicCommentId() {
		return dynamicCommentId;
	}

	public void setDynamicCommentId(Integer dynamicCommentId) {
		this.dynamicCommentId = dynamicCommentId;
	}

	public Integer getDynamicCommentAuthor() {
		return dynamicCommentAuthor;
	}

	public void setDynamicCommentAuthor(Integer dynamicCommentAuthor) {
		this.dynamicCommentAuthor = dynamicCommentAuthor;
	}

	public Integer getCircleDynamicId() {
		return circleDynamicId;
	}

	public void setCircleDynamicId(Integer circleDynamicId) {
		this.circleDynamicId = circleDynamicId;
	}

	public Integer getDynamicReplyUser() {
		return dynamicReplyUser;
	}

	public void setDynamicReplyUser(Integer dynamicReplyUser) {
		this.dynamicReplyUser = dynamicReplyUser;
	}

	public String getDynamicCommentContent() {
		return dynamicCommentContent;
	}

	public void setDynamicCommentContent(String dynamicCommentContent) {
		this.dynamicCommentContent = dynamicCommentContent;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.dynamicCommentId;
	}

	@Override
	public String toString() {
		return "DynamicComment{" +
			"dynamicCommentId=" + dynamicCommentId +
			", dynamicCommentAuthor=" + dynamicCommentAuthor +
			", circleDynamicId=" + circleDynamicId +
			", dynamicReplyUser=" + dynamicReplyUser +
			", dynamicCommentContent=" + dynamicCommentContent +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
