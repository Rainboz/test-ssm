package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("my_practical_training")
public class MyPracticalTraining extends Model<MyPracticalTraining> {

    private static final long serialVersionUID = 1L;

	@TableId(value="my_practical_training_id", type= IdType.AUTO)
	private Integer myPracticalTrainingId;
	@TableField("practical_training_id")
	private Integer practicalTrainingId;
	@TableField("my_practical_training_file")
	private String myPracticalTrainingFile;
	@TableField("my_practical_training_grade")
	private Integer myPracticalTrainingGrade;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getMyPracticalTrainingId() {
		return myPracticalTrainingId;
	}

	public void setMyPracticalTrainingId(Integer myPracticalTrainingId) {
		this.myPracticalTrainingId = myPracticalTrainingId;
	}

	public Integer getPracticalTrainingId() {
		return practicalTrainingId;
	}

	public void setPracticalTrainingId(Integer practicalTrainingId) {
		this.practicalTrainingId = practicalTrainingId;
	}

	public String getMyPracticalTrainingFile() {
		return myPracticalTrainingFile;
	}

	public void setMyPracticalTrainingFile(String myPracticalTrainingFile) {
		this.myPracticalTrainingFile = myPracticalTrainingFile;
	}

	public Integer getMyPracticalTrainingGrade() {
		return myPracticalTrainingGrade;
	}

	public void setMyPracticalTrainingGrade(Integer myPracticalTrainingGrade) {
		this.myPracticalTrainingGrade = myPracticalTrainingGrade;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.myPracticalTrainingId;
	}

	@Override
	public String toString() {
		return "MyPracticalTraining{" +
			"myPracticalTrainingId=" + myPracticalTrainingId +
			", practicalTrainingId=" + practicalTrainingId +
			", myPracticalTrainingFile=" + myPracticalTrainingFile +
			", myPracticalTrainingGrade=" + myPracticalTrainingGrade +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
