package com.http.service.serviceImpl;

import java.util.List;

import javax.annotation.Resource;

import com.http.model.User;
import com.http.dao.UserDao;
import com.http.service.UserService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserDao, User> implements
		UserService {
	@Resource
	private UserDao userDao;

	@Override
	public List<User> findAll() {
		List<User> userlist = userDao.findAll();
		return userlist;
	}

	@Override
	public User selectByPrimaryKey(Integer id) {

		return userDao.selectByPrimaryKey(id);
	}

}
