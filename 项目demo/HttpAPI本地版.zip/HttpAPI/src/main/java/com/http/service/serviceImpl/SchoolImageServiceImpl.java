package com.http.service.serviceImpl;

import com.http.model.SchoolImage;
import com.http.dao.SchoolImageDao;
import com.http.service.SchoolImageService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class SchoolImageServiceImpl extends ServiceImpl<SchoolImageDao, SchoolImage> implements SchoolImageService {
	
}
