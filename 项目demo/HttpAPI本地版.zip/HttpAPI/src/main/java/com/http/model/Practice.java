package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Practice extends Model<Practice> {

    private static final long serialVersionUID = 1L;

	@TableId(value="practice_id", type= IdType.AUTO)
	private Integer practiceId;
	@TableField("user_id")
	private Integer userId;
	@TableField("exam_item_id")
	private Integer examItemId;
	@TableField("practice_answer")
	private String practiceAnswer;
	@TableField("practice_grade")
	private Integer practiceGrade;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getPracticeId() {
		return practiceId;
	}

	public void setPracticeId(Integer practiceId) {
		this.practiceId = practiceId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getExamItemId() {
		return examItemId;
	}

	public void setExamItemId(Integer examItemId) {
		this.examItemId = examItemId;
	}

	public String getPracticeAnswer() {
		return practiceAnswer;
	}

	public void setPracticeAnswer(String practiceAnswer) {
		this.practiceAnswer = practiceAnswer;
	}

	public Integer getPracticeGrade() {
		return practiceGrade;
	}

	public void setPracticeGrade(Integer practiceGrade) {
		this.practiceGrade = practiceGrade;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.practiceId;
	}

	@Override
	public String toString() {
		return "Practice{" +
			"practiceId=" + practiceId +
			", userId=" + userId +
			", examItemId=" + examItemId +
			", practiceAnswer=" + practiceAnswer +
			", practiceGrade=" + practiceGrade +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
