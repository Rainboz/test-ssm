package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Task extends Model<Task> {

    private static final long serialVersionUID = 1L;

	@TableId(value="task_id", type= IdType.AUTO)
	private Integer taskId;
	@TableField("task_name")
	private String taskName;
	@TableField("task_type")
	private Integer taskType;
	@TableField("course_id")
	private Integer courseId;
	@TableField("task_start_time")
	private Date taskStartTime;
	@TableField("task_end_time")
	private Date taskEndTime;
	@TableField("task_state")
	private Integer taskState;
	@TableField("task_publish")
	private Integer taskPublish;
	@TableField("task_link")
	private String taskLink;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public Integer getTaskType() {
		return taskType;
	}

	public void setTaskType(Integer taskType) {
		this.taskType = taskType;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public Date getTaskStartTime() {
		return taskStartTime;
	}

	public void setTaskStartTime(Date taskStartTime) {
		this.taskStartTime = taskStartTime;
	}

	public Date getTaskEndTime() {
		return taskEndTime;
	}

	public void setTaskEndTime(Date taskEndTime) {
		this.taskEndTime = taskEndTime;
	}

	public Integer getTaskState() {
		return taskState;
	}

	public void setTaskState(Integer taskState) {
		this.taskState = taskState;
	}

	public Integer getTaskPublish() {
		return taskPublish;
	}

	public void setTaskPublish(Integer taskPublish) {
		this.taskPublish = taskPublish;
	}

	public String getTaskLink() {
		return taskLink;
	}

	public void setTaskLink(String taskLink) {
		this.taskLink = taskLink;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.taskId;
	}

	@Override
	public String toString() {
		return "Task{" +
			"taskId=" + taskId +
			", taskName=" + taskName +
			", taskType=" + taskType +
			", courseId=" + courseId +
			", taskStartTime=" + taskStartTime +
			", taskEndTime=" + taskEndTime +
			", taskState=" + taskState +
			", taskPublish=" + taskPublish +
			", taskLink=" + taskLink +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
