package com.http.dao;

import com.http.model.Communication;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public interface CommunicationDao extends BaseMapper<Communication> {

}