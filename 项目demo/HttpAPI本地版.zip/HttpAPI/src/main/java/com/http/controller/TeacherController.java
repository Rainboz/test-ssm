package com.http.controller;


import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.stereotype.Controller;

import com.http.common.util.Constant;
import com.http.model.Course;
import com.http.service.CourseService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Controller
@RequestMapping("/teacher")
@ResponseBody
public class TeacherController {
	@Resource
    private CourseService courseService;
	@RequestMapping(value = "/MyCourse",method = RequestMethod.GET)
    public Map<String,Object>  getMyCourse(ModelAndView modelAndView,
                                           @RequestParam(required = true) Integer teacherId){

        List<Course> courseBeanList = courseService.getCourseList(teacherId);
        modelAndView.addObject("result_code",Constant.SUCCESS_CODE);
        modelAndView.addObject("message",Constant.SUCCESS_MESSAGE);
        modelAndView.addObject("return_data", courseBeanList );
        return  modelAndView.getModel();
    }
}
