package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("school_information")
public class SchoolInformation extends Model<SchoolInformation> {

    private static final long serialVersionUID = 1L;

	@TableId(value="school_information_id", type= IdType.AUTO)
	private Integer schoolInformationId;
	@TableField("school_information_title")
	private String schoolInformationTitle;
	@TableField("school_information_author")
	private String schoolInformationAuthor;
	@TableField("school_information_content")
	private String schoolInformationContent;
	@TableField("school_id")
	private Integer schoolId;
	@TableField("information_image_count")
	private Integer informationImageCount;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getSchoolInformationId() {
		return schoolInformationId;
	}

	public void setSchoolInformationId(Integer schoolInformationId) {
		this.schoolInformationId = schoolInformationId;
	}

	public String getSchoolInformationTitle() {
		return schoolInformationTitle;
	}

	public void setSchoolInformationTitle(String schoolInformationTitle) {
		this.schoolInformationTitle = schoolInformationTitle;
	}

	public String getSchoolInformationAuthor() {
		return schoolInformationAuthor;
	}

	public void setSchoolInformationAuthor(String schoolInformationAuthor) {
		this.schoolInformationAuthor = schoolInformationAuthor;
	}

	public String getSchoolInformationContent() {
		return schoolInformationContent;
	}

	public void setSchoolInformationContent(String schoolInformationContent) {
		this.schoolInformationContent = schoolInformationContent;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public Integer getInformationImageCount() {
		return informationImageCount;
	}

	public void setInformationImageCount(Integer informationImageCount) {
		this.informationImageCount = informationImageCount;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.schoolInformationId;
	}

	@Override
	public String toString() {
		return "SchoolInformation{" +
			"schoolInformationId=" + schoolInformationId +
			", schoolInformationTitle=" + schoolInformationTitle +
			", schoolInformationAuthor=" + schoolInformationAuthor +
			", schoolInformationContent=" + schoolInformationContent +
			", schoolId=" + schoolId +
			", informationImageCount=" + informationImageCount +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
