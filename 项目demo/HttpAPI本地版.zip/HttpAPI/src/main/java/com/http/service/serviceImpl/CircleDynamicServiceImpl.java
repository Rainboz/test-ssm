package com.http.service.serviceImpl;

import com.http.model.CircleDynamic;
import com.http.dao.CircleDynamicDao;
import com.http.service.CircleDynamicService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class CircleDynamicServiceImpl extends ServiceImpl<CircleDynamicDao, CircleDynamic> implements CircleDynamicService {
	
}
