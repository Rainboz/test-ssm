package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("circle_dynamic")
public class CircleDynamic extends Model<CircleDynamic> {

    private static final long serialVersionUID = 1L;

	@TableId(value="circle_dynamic_id", type= IdType.AUTO)
	private Integer circleDynamicId;
	@TableField("school_id")
	private Integer schoolId;
	@TableField("circle_dynamic_author")
	private Integer circleDynamicAuthor;
	@TableField("circle_dynamic_content")
	private String circleDynamicContent;
	@TableField("dynamic_image_count")
	private Integer dynamicImageCount;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCircleDynamicId() {
		return circleDynamicId;
	}

	public void setCircleDynamicId(Integer circleDynamicId) {
		this.circleDynamicId = circleDynamicId;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public Integer getCircleDynamicAuthor() {
		return circleDynamicAuthor;
	}

	public void setCircleDynamicAuthor(Integer circleDynamicAuthor) {
		this.circleDynamicAuthor = circleDynamicAuthor;
	}

	public String getCircleDynamicContent() {
		return circleDynamicContent;
	}

	public void setCircleDynamicContent(String circleDynamicContent) {
		this.circleDynamicContent = circleDynamicContent;
	}

	public Integer getDynamicImageCount() {
		return dynamicImageCount;
	}

	public void setDynamicImageCount(Integer dynamicImageCount) {
		this.dynamicImageCount = dynamicImageCount;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.circleDynamicId;
	}

	@Override
	public String toString() {
		return "CircleDynamic{" +
			"circleDynamicId=" + circleDynamicId +
			", schoolId=" + schoolId +
			", circleDynamicAuthor=" + circleDynamicAuthor +
			", circleDynamicContent=" + circleDynamicContent +
			", dynamicImageCount=" + dynamicImageCount +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
