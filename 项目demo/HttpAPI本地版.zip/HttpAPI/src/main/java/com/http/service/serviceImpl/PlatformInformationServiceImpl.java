package com.http.service.serviceImpl;

import com.http.model.PlatformInformation;
import com.http.dao.PlatformInformationDao;
import com.http.service.PlatformInformationService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class PlatformInformationServiceImpl extends ServiceImpl<PlatformInformationDao, PlatformInformation> implements PlatformInformationService {
	
}
