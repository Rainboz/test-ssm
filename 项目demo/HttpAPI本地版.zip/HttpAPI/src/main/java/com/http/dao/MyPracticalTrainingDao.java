package com.http.dao;

import com.http.model.MyPracticalTraining;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public interface MyPracticalTrainingDao extends BaseMapper<MyPracticalTraining> {

}