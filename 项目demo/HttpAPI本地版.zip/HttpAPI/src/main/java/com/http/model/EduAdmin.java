package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("edu_admin")
public class EduAdmin extends Model<EduAdmin> {

    private static final long serialVersionUID = 1L;

	@TableId(value="edu_admin_id", type= IdType.AUTO)
	private Integer eduAdminId;
	@TableField("school_id")
	private Integer schoolId;
	@TableField("edu_admin_number")
	private String eduAdminNumber;
	@TableField("edu_admin_name")
	private String eduAdminName;
	@TableField("edu_admin_password")
	private String eduAdminPassword;
	@TableField("edu_admin_authority")
	private String eduAdminAuthority;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getEduAdminId() {
		return eduAdminId;
	}

	public void setEduAdminId(Integer eduAdminId) {
		this.eduAdminId = eduAdminId;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public String getEduAdminNumber() {
		return eduAdminNumber;
	}

	public void setEduAdminNumber(String eduAdminNumber) {
		this.eduAdminNumber = eduAdminNumber;
	}

	public String getEduAdminName() {
		return eduAdminName;
	}

	public void setEduAdminName(String eduAdminName) {
		this.eduAdminName = eduAdminName;
	}

	public String getEduAdminPassword() {
		return eduAdminPassword;
	}

	public void setEduAdminPassword(String eduAdminPassword) {
		this.eduAdminPassword = eduAdminPassword;
	}

	public String getEduAdminAuthority() {
		return eduAdminAuthority;
	}

	public void setEduAdminAuthority(String eduAdminAuthority) {
		this.eduAdminAuthority = eduAdminAuthority;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.eduAdminId;
	}

	@Override
	public String toString() {
		return "EduAdmin{" +
			"eduAdminId=" + eduAdminId +
			", schoolId=" + schoolId +
			", eduAdminNumber=" + eduAdminNumber +
			", eduAdminName=" + eduAdminName +
			", eduAdminPassword=" + eduAdminPassword +
			", eduAdminAuthority=" + eduAdminAuthority +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
