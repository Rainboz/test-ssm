package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
public class Ability extends Model<Ability> {

    private static final long serialVersionUID = 1L;

	@TableId(value="ability_id", type= IdType.AUTO)
	private Integer abilityId;
	@TableField("student_id")
	private Integer studentId;
	@TableField("ability_theory")
	private Integer abilityTheory;
	@TableField("ability_practice")
	private Integer abilityPractice;
	@TableField("ability_language")
	private Integer abilityLanguage;
	@TableField("ability_innovate")
	private Integer abilityInnovate;
	@TableField("ability_think")
	private Integer abilityThink;
	@TableField("ability_teamwork")
	private Integer abilityTeamwork;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getAbilityId() {
		return abilityId;
	}

	public void setAbilityId(Integer abilityId) {
		this.abilityId = abilityId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getAbilityTheory() {
		return abilityTheory;
	}

	public void setAbilityTheory(Integer abilityTheory) {
		this.abilityTheory = abilityTheory;
	}

	public Integer getAbilityPractice() {
		return abilityPractice;
	}

	public void setAbilityPractice(Integer abilityPractice) {
		this.abilityPractice = abilityPractice;
	}

	public Integer getAbilityLanguage() {
		return abilityLanguage;
	}

	public void setAbilityLanguage(Integer abilityLanguage) {
		this.abilityLanguage = abilityLanguage;
	}

	public Integer getAbilityInnovate() {
		return abilityInnovate;
	}

	public void setAbilityInnovate(Integer abilityInnovate) {
		this.abilityInnovate = abilityInnovate;
	}

	public Integer getAbilityThink() {
		return abilityThink;
	}

	public void setAbilityThink(Integer abilityThink) {
		this.abilityThink = abilityThink;
	}

	public Integer getAbilityTeamwork() {
		return abilityTeamwork;
	}

	public void setAbilityTeamwork(Integer abilityTeamwork) {
		this.abilityTeamwork = abilityTeamwork;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.abilityId;
	}

	@Override
	public String toString() {
		return "Ability{" +
			"abilityId=" + abilityId +
			", studentId=" + studentId +
			", abilityTheory=" + abilityTheory +
			", abilityPractice=" + abilityPractice +
			", abilityLanguage=" + abilityLanguage +
			", abilityInnovate=" + abilityInnovate +
			", abilityThink=" + abilityThink +
			", abilityTeamwork=" + abilityTeamwork +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
