package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("dynamic_praise")
public class DynamicPraise extends Model<DynamicPraise> {

    private static final long serialVersionUID = 1L;

	@TableId(value="dynamic_praise_id", type= IdType.AUTO)
	private Integer dynamicPraiseId;
	@TableField("dynamic_praise_user")
	private Integer dynamicPraiseUser;
	@TableField("circle_dynamic_id")
	private Integer circleDynamicId;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getDynamicPraiseId() {
		return dynamicPraiseId;
	}

	public void setDynamicPraiseId(Integer dynamicPraiseId) {
		this.dynamicPraiseId = dynamicPraiseId;
	}

	public Integer getDynamicPraiseUser() {
		return dynamicPraiseUser;
	}

	public void setDynamicPraiseUser(Integer dynamicPraiseUser) {
		this.dynamicPraiseUser = dynamicPraiseUser;
	}

	public Integer getCircleDynamicId() {
		return circleDynamicId;
	}

	public void setCircleDynamicId(Integer circleDynamicId) {
		this.circleDynamicId = circleDynamicId;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.dynamicPraiseId;
	}

	@Override
	public String toString() {
		return "DynamicPraise{" +
			"dynamicPraiseId=" + dynamicPraiseId +
			", dynamicPraiseUser=" + dynamicPraiseUser +
			", circleDynamicId=" + circleDynamicId +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
