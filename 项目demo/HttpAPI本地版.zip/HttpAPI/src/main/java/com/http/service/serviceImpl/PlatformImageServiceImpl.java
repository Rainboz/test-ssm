package com.http.service.serviceImpl;

import com.http.model.PlatformImage;
import com.http.dao.PlatformImageDao;
import com.http.service.PlatformImageService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Service
public class PlatformImageServiceImpl extends ServiceImpl<PlatformImageDao, PlatformImage> implements PlatformImageService {
	
}
