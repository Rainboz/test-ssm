package com.http.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Controller
@RequestMapping("/platformBill")
public class PlatformBillController {
	
}
