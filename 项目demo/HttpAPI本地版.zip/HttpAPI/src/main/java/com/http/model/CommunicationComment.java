package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("communication_comment")
public class CommunicationComment extends Model<CommunicationComment> {

    private static final long serialVersionUID = 1L;

	@TableId(value="communication_comment_id", type= IdType.AUTO)
	private Integer communicationCommentId;
	@TableField("communication_id")
	private Integer communicationId;
	@TableField("communication_comment_user")
	private Integer communicationCommentUser;
	@TableField("communication_reply")
	private Integer communicationReply;
	@TableField("communication_comment_content")
	private String communicationCommentContent;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getCommunicationCommentId() {
		return communicationCommentId;
	}

	public void setCommunicationCommentId(Integer communicationCommentId) {
		this.communicationCommentId = communicationCommentId;
	}

	public Integer getCommunicationId() {
		return communicationId;
	}

	public void setCommunicationId(Integer communicationId) {
		this.communicationId = communicationId;
	}

	public Integer getCommunicationCommentUser() {
		return communicationCommentUser;
	}

	public void setCommunicationCommentUser(Integer communicationCommentUser) {
		this.communicationCommentUser = communicationCommentUser;
	}

	public Integer getCommunicationReply() {
		return communicationReply;
	}

	public void setCommunicationReply(Integer communicationReply) {
		this.communicationReply = communicationReply;
	}

	public String getCommunicationCommentContent() {
		return communicationCommentContent;
	}

	public void setCommunicationCommentContent(String communicationCommentContent) {
		this.communicationCommentContent = communicationCommentContent;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.communicationCommentId;
	}

	@Override
	public String toString() {
		return "CommunicationComment{" +
			"communicationCommentId=" + communicationCommentId +
			", communicationId=" + communicationId +
			", communicationCommentUser=" + communicationCommentUser +
			", communicationReply=" + communicationReply +
			", communicationCommentContent=" + communicationCommentContent +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
