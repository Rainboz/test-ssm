package com.http.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.math.BigDecimal;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@TableName("platform_bill")
public class PlatformBill extends Model<PlatformBill> {

    private static final long serialVersionUID = 1L;

	@TableId(value="platform_bill_id", type= IdType.AUTO)
	private Integer platformBillId;
	@TableField("platform_bill_title")
	private String platformBillTitle;
	@TableField("platform_bill_detail")
	private String platformBillDetail;
	@TableField("platform_bill_money")
	private BigDecimal platformBillMoney;
	@TableField("platform_bill_balance")
	private BigDecimal platformBillBalance;
	@TableField("gmt_del")
	private Integer gmtDel;
	@TableField("gmt_create")
	private Date gmtCreate;
	@TableField("gmt_modified")
	private Date gmtModified;


	public Integer getPlatformBillId() {
		return platformBillId;
	}

	public void setPlatformBillId(Integer platformBillId) {
		this.platformBillId = platformBillId;
	}

	public String getPlatformBillTitle() {
		return platformBillTitle;
	}

	public void setPlatformBillTitle(String platformBillTitle) {
		this.platformBillTitle = platformBillTitle;
	}

	public String getPlatformBillDetail() {
		return platformBillDetail;
	}

	public void setPlatformBillDetail(String platformBillDetail) {
		this.platformBillDetail = platformBillDetail;
	}

	public BigDecimal getPlatformBillMoney() {
		return platformBillMoney;
	}

	public void setPlatformBillMoney(BigDecimal platformBillMoney) {
		this.platformBillMoney = platformBillMoney;
	}

	public BigDecimal getPlatformBillBalance() {
		return platformBillBalance;
	}

	public void setPlatformBillBalance(BigDecimal platformBillBalance) {
		this.platformBillBalance = platformBillBalance;
	}

	public Integer getGmtDel() {
		return gmtDel;
	}

	public void setGmtDel(Integer gmtDel) {
		this.gmtDel = gmtDel;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	@Override
	protected Serializable pkVal() {
		return this.platformBillId;
	}

	@Override
	public String toString() {
		return "PlatformBill{" +
			"platformBillId=" + platformBillId +
			", platformBillTitle=" + platformBillTitle +
			", platformBillDetail=" + platformBillDetail +
			", platformBillMoney=" + platformBillMoney +
			", platformBillBalance=" + platformBillBalance +
			", gmtDel=" + gmtDel +
			", gmtCreate=" + gmtCreate +
			", gmtModified=" + gmtModified +
			"}";
	}
}
