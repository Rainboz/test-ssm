package com.http.controller;


import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.http.common.util.Msg;
import com.http.model.User;
import com.http.service.UserService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhb
 * @since 2018-07-19
 */
@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	
	@RequestMapping("/")
	public ModelAndView index(ModelAndView modelAndView){
		modelAndView.setViewName("index");
		return modelAndView;
	}
	@RequestMapping("/getAllUser")
	public String getAllUser(Map<String, Object> map ){
		List<User> users = userService.findAll();
		map.put("ALLUSER", users);
		return "allUser";
	}
	@RequestMapping(value = "/Select",method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> getAnnouncement(ModelAndView modelAndView,@RequestParam(required = true,defaultValue = "1") Integer id){
		User uList = userService.selectByPrimaryKey(id);
		modelAndView.addObject("result_code", "0");
		modelAndView.addObject("message", "執行成功");
		modelAndView.addObject("return_data", uList);
		return modelAndView.getModel();
	}
	@RequestMapping(value = "/test",method = RequestMethod.GET)
	@ResponseBody
	public Msg getListWithJson(@RequestParam(required = true,defaultValue = "1") Integer id){
		User uList = userService.selectByPrimaryKey(id);
//		modelAndView.addObject("result_code", "0");
//		modelAndView.addObject("message", "執行成功");
//		modelAndView.addObject("return_data", uList);
		return Msg.success().add("return_data", uList);
	}
	
	
}
