package com.zhb.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zhb.ssm.mapper.UserMapper;
import com.zhb.ssm.model.User;
import com.zhb.ssm.service.UserService;
//可以消除xml中对bean的配置
@Service
//此处使用spring的声明式事务，不在使用sqlsession和提交事务了
@Transactional
public class UserServiceImpl implements UserService{
	@Resource
	private UserMapper mapper;

	/**
	 * 查询User表所有数据
	 */
	@Override
	public List<User> findAll() {
		List<User> list = mapper.findAll();
		return list;
	}
	
	@Override
	public int deleteByPrimaryKey(Integer userId) {
		return mapper.deleteByPrimaryKey(userId);
	}

	@Override
	public int insert(User record) {
		return mapper.insert(record);
	}

	@Override
	public int insertSelective(User record) {
		return mapper.insertSelective(record);
	}

	@Override
	public User selectByPrimaryKey(Integer userId) {
		return mapper.selectByPrimaryKey(userId);
	}

	@Override
	public int updateByPrimaryKeySelective(User record) {
		return mapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(User record) {
		return mapper.updateByPrimaryKey(record);
	}

}
