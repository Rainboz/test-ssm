package com.zhb.ssm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AjaxController {
@ResponseBody
@RequestMapping(value = "area/delete",method = RequestMethod.POST)
public String editAreaWithFile(String param1,Long areaId,@RequestParam("deleteId") Long deleteId,Long[] ids) {
    //处理参数
     //这时ids数组为[254,249,248]
    return "成功";
}
}
