package com.zhb.ssm.controller;

import java.util.List;
import java.util.Map;

import net.sf.json.util.JSONUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.zhb.ssm.model.User;
import com.zhb.ssm.service.UserService;
import com.zhb.ssm.service.impl.UserServiceImpl;

@Controller
@RequestMapping(value = "/user")
public class UserController {
	@Autowired
	private UserService userService;
	private UserServiceImpl userServiceImpl;
	
	@RequestMapping(value = "/getAllUser")
	public String getAllUser(Map<String, Object> map) {
		List<User> userlist = userService.findAll();
		map.put("ALLUSER", userlist);
		return "allUser";
	}
	@RequestMapping(value = "/hello")
	public String Hello(){
		System.err.println("sdfs");
//		User userlist = userService.selectByPrimaryKey(1);
		
	
		return "hello";
	}
	@RequestMapping(value = "/test")
	public String Test(ModelMap model){
		 model.addAttribute("message", "Hello Spring MVC Framework!");
	     return "test";
	}
	
	@RequestMapping(value = "/Select",method = RequestMethod.GET)
	public Map<String, Object> getAnnouncement(ModelAndView modelAndView,@RequestParam(required = true,defaultValue = "5") Integer userId){
//		User user = userService.selectByPrimaryKey(userId);
//		if (user != null) {
//			modelAndView.addObject("result_code", 7701);
//			modelAndView.addObject("message", "選擇失敗");
//			modelAndView.addObject("return_data", null);
//            return modelAndView.getModel();
//		}
//		 User user2 = new User();
//		 user2.setUserId(userId);
//		 userServiceImpl.selectByPrimaryKey(userId);
//		return modelAndView.getModel();
		List<User> uList = userService.findAll();
		modelAndView.addObject("result_code", "0");
		modelAndView.addObject("message", "執行成功");
		modelAndView.addObject("return_data", uList);
		return modelAndView.getModel();
	}
	
}
